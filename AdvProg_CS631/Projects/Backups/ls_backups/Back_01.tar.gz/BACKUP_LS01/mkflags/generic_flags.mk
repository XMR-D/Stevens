CC= gcc
CFLAGS= -Wall -Wextra -Werror -pedantic -std=gnu99 -Ofast -I src/include
DEBUGFLAGS= -g -fsanitize=address -O0 -Wall -Wextra -Werror -pedantic -std=gnu99 -I src/include
LDFLAGS= -lasan
SRC_DIR= src
