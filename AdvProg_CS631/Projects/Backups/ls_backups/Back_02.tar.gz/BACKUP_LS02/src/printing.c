#include <sys/ioctl.h>

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "error.h"
#include "list-handling.h"
#include "opt_parser.h"
#include "utility.h"

#include "printing.h"

/* TODO DEBUG THIS LAST STEP + ADD options handling */
static void PrintListing(FileList * list, int longest, int row_nb, int col_nb)
{
    /* Setup the start of the list (first elm) */
    if (!list->fname && list->next)
        list = list->next;

    FileList * start = list;
    FileList * curr = list;
    int step = row_nb;
    int new_row = 0;
    /* 
     * If the list contain only one element 
     * Print it, and return
     */
    if (!curr->next)
    {
    	printf("%s\n", curr->fname);
	return;
    }
    
    
    printf("%s", curr->fname);
    Padding(curr->fname, longest);

    for (int i = 0; i < row_nb; i++)
    {
	if (new_row)
	{
	    printf("%s", curr->fname);
	    Padding(curr->fname, longest);
	    new_row--;
	}

        for (int j = 0; j < col_nb; j++)
        {
           
	    /* Shift to next element to print in the linked list */	
            while (step > 0)
            {
                if (!curr->next)
                    break;

                curr = curr->next;
                step--;
            }
	    
            /* 
	     * If on the last element after shifting
	     * and that we do not need to shift anymore print
	     * and proceed to the next row
	     */	    
            if (!curr->next && step == 0)
	    {
		printf("%s", curr->fname);
		break;
	    }

	    /*
	     * If after shifting we found an element print it with padding
	     * and reset the step for the next_path
	     */
            if (curr->next)
	    {
		step = row_nb;
                printf("%s", curr->fname);
                Padding(curr->fname, longest);
	    }

        }
	new_row++;
	step = row_nb; 
        start = start->next;
        curr = start;
        printf("\n");
    }
    printf("\n");
}


static int GetWinWidth(void)
{
    struct winsize w;
    ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
    return w.ws_col;
}

static int GetMaxLen(FileList * list, int * nb_files)
{
    int max = 0;
    int curr_len = 0;

    if (!list->fname && list->next)
        list = list->next;

    while (list)
    {	
	curr_len = strlen(list->fname);
        
	(*nb_files)++;

        if (max < curr_len)
            max = curr_len;

        list = list->next;
    }
    return max;
}


void ClassicPrinter(FileList * list)
{
    /* If the list is empty (no files to print) return */
    if (!list->next)
        return;
    /* 
     * Compute rows and columns to print the files
     * The width of a column is the size of the largest file + 2 for padding
     * Given by GetMaxLen(list);
     * Get the width of the terminal to compute how to print the output
     * Given by GetWinWidth();
    */

    int nb_files = 0;
    int longest = GetMaxLen(list, &nb_files);
    int col_nb = GetWinWidth() / longest;
    int row_nb = (nb_files + col_nb - 1) / col_nb;
    PrintListing(list, longest, row_nb, col_nb);
}

void LongFormatPrinter(FileList * list)
{
    ClassicPrinter(list);
    return;
}
