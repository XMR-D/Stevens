#include <sys/ioctl.h>
#include <sys/stat.h>

#include <errno.h>
#include <pwd.h>
#include <grp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "error.h"
#include "list-handling.h"
#include "opt_parser.h"
#include "utility.h"

#include "printing.h"

extern UsrOptions * usr_opt;

extern int max_uid_len;
extern int max_gid_len;
extern int max_uid_int_len;
extern int max_gid_int_len;

/* TODO DEBUG THIS LAST STEP + ADD options handling */
static void PrintListing(FileList * list, int longest, int row_nb, int col_nb)
{
    /* Setup the start of the list (first elm) */
    if (!list->fname && list->next)
        list = list->next;

    FileList * start = list;
    FileList * curr = list;
    int step = row_nb;
    int new_row = 0;
    /* 
     * If the list contain only one element 
     * Print it, and return
     */
    if (!curr->next)
    {
    	printf("%s\n", curr->fname);
	return;
    }
    
    
    printf("%s", curr->fname);
    Padding(curr->fname, longest);

    for (int i = 0; i < row_nb; i++)
    {
	if (new_row)
	{
	    printf("%s", curr->fname);
	    Padding(curr->fname, longest);
	    new_row--;
	}

        for (int j = 0; j < col_nb; j++)
        {
           
	    /* Shift to next element to print in the linked list */	
            while (step > 0)
            {
                if (!curr->next)
                    break;

                curr = curr->next;
                step--;
            }
	    
            /* 
	     * If on the last element after shifting
	     * and that we do not need to shift anymore print
	     * and proceed to the next row
	     */	    
            if (!curr->next && step == 0)
	    {
		printf("%s", curr->fname);
		break;
	    }

	    /*
	     * If after shifting we found an element print it with padding
	     * and reset the step for the next_path
	     */
            if (curr->next)
	    {
		step = row_nb;
                printf("%s", curr->fname);
                Padding(curr->fname, longest);
	    }

        }
	new_row++;
	step = row_nb; 
        start = start->next;
        curr = start;
        printf("\n");
    }
    printf("\n");
}


static int GetWinWidth(void)
{
    struct winsize w;
    ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
    return w.ws_col;
}

static int GetMaxLen(FileList * list, int * nb_files)
{
    int max = 0;
    int curr_len = 0;

    if (!list->fname && list->next)
        list = list->next;

    while (list)
    {	
	curr_len = strlen(list->fname);
        
	(*nb_files)++;

        if (max < curr_len)
            max = curr_len;

        list = list->next;
    }
    return max;
}


void ClassicPrinter(FileList * list)
{
    /* If the list is empty (no files to print) return */
    if (!list->next)
        return;
    /* 
     * Compute rows and columns to print the files
     * The width of a column is the size of the largest file + 2 for padding
     * Given by GetMaxLen(list);
     * Get the width of the terminal to compute how to print the output
     * Given by GetWinWidth();
    */

    int nb_files = 0;
    int longest = GetMaxLen(list, &nb_files);
    int col_nb = GetWinWidth() / longest;
    int row_nb = (nb_files + col_nb - 1) / col_nb;
    PrintListing(list, longest, row_nb, col_nb);
}

static void PrintFileType(FileList * elm)
{
    if (S_ISWHT(elm->sb.st_mode))
        printf("w");

    else if (S_ISREG(elm->sb.st_mode))
    {
	//TODO CHANGE THESES TO CORRETLY PRINT A and a
	if (elm->sb.st_flags & SF_ARCHIVED)
	    printf("a");
	if (elm->sb.st_flags & SF_ARCHIVED)
	    printf("A");
	else
	    printf("-");
    }
    else if (S_ISDIR(elm->sb.st_mode))
        printf("d");
    else if (S_ISCHR(elm->sb.st_mode))
        printf("c");
    else if (S_ISBLK(elm->sb.st_mode))
        printf("b");
    else if (S_ISFIFO(elm->sb.st_mode))
        printf("p");
    else if (S_ISLNK(elm->sb.st_mode))
        printf("l");
    else if (S_ISSOCK(elm->sb.st_mode))
	printf("s");
    
    return;
}

static void PrintPermission(FileList *elm, int field, char * permission)
{
     //TODO : ADD STICKY BIT AND Set user ID mode
     if (elm->sb.st_mode & field)
         printf("%s", permission);
     else
	 printf("-");
}

static void PrintFileMode(FileList * elm)
{
    /* file type */
    PrintFileType(elm);
    
    /* owner permissions */
    PrintPermission(elm, S_IRUSR, "r");	
    PrintPermission(elm, S_IWUSR, "w");	
    PrintPermission(elm, S_IXUSR, "x");	
    
    /* group permissions */
    PrintPermission(elm, S_IRGRP, "r");	
    PrintPermission(elm, S_IWGRP, "w");	
    PrintPermission(elm, S_IXGRP, "x");

    /* other permissions */    
    PrintPermission(elm, S_IROTH, "r");	
    PrintPermission(elm, S_IWOTH, "w");	
    PrintPermission(elm, S_IXOTH, "x");

    printf(" ");    
}

static void PrintOwner(FileList * elm)
{
    if (!usr_opt->n)
    {
        struct passwd * pwd = getpwuid(elm->sb.st_uid);
	
	if (pwd == NULL)
	{
	    char * uid_int_str = IntToAscii(elm->sb.st_uid);
	    printf("%d", elm->sb.st_uid);
	    Padding(uid_int_str, max_uid_int_len);
	    free(uid_int_str);
	}
	else
	{
	    printf("%s", pwd->pw_name);
	    Padding(pwd->pw_name, max_uid_len);
	}
    }
    else
    {
	char * uid_int_str = IntToAscii(elm->sb.st_uid);
        printf("%d", elm->sb.st_uid);
	Padding(uid_int_str, max_uid_int_len);
	free(uid_int_str);
    }

    
}

static void PrintGroup(FileList * elm)
{
    if (!usr_opt->n)
    {
        struct group * grp = getgrgid(elm->sb.st_gid);
	
	if (grp == NULL)
	{
	    char * gid_int_str = IntToAscii(elm->sb.st_gid);
	    printf("%d", elm->sb.st_gid);
	    Padding(gid_int_str, max_gid_int_len);
	    free(gid_int_str);
	}
	else
	{
	    printf("%s", grp->gr_name);
	    Padding(grp->gr_name, max_gid_len);
	}
    }
    else
    {
	char * gid_int_str = IntToAscii(elm->sb.st_gid);
        printf("%d", elm->sb.st_gid);
	Padding(gid_int_str, max_gid_int_len);
	free(gid_int_str);
    }   
}

static void PrintByteNb(FileList * elm)
{
    //TODO
    elm->ishidden++;
    elm->ishidden--;
}

static void PrintDate(FileList * elm)
{
     //TODO
     elm->ishidden++;
     elm->ishidden--;
}

void LongFormatPrinter(FileList * list)
{
    /* Skip head element */
    list = list->next;

    while (list)
    {
	PrintFileMode(list);

	/* number of links */
	printf("%i ", list->sb.st_nlink);
	
	PrintOwner(list);
	PrintGroup(list);
	
	PrintByteNb(list);
	PrintDate(list);
	printf("%s\n", list->fname);
        
	list = list->next;
    }
    return;
}
