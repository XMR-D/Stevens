#include "echo.h"

#include <stdio.h>
#include <stdlib.h>

int echo_main(void)
{
	printf("Welcome to cd_main !\n");
	return EXIT_SUCCESS;
}
